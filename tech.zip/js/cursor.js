/**
 * Custom Cursor
 * Advanced cursor effects and interactions
 */

class Cursor {
  constructor() {
    this.cursorDot = document.querySelector('.cursor-dot');
    this.cursorOutline = document.querySelector('.cursor-outline');
    this.cursorTrail = document.querySelector('.cursor-trail');
    this.cursor = document.querySelector('.custom-cursor');
    
    this.position = { x: 0, y: 0 };
    this.previousPosition = { x: 0, y: 0 };
    this.targetPosition = { x: 0, y: 0 };
    this.cursorSize = 8; // Default cursor dot size in pixels
    this.isVisible = false;
    this.isActive = false;
    this.isHovering = false;
    
    this.trailPoints = [];
    this.trailPointsCount = 10;
    
    // Check if cursor elements exist
    if (this.cursorDot && this.cursorOutline && this.cursorTrail) {
      this.init();
    }
  }

  init() {
    // Initialize cursor position to center of screen
    this.position.x = window.innerWidth / 2;
    this.position.y = window.innerHeight / 2;
    this.previousPosition.x = this.position.x;
    this.previousPosition.y = this.position.y;
    
    // Initialize trail points
    for (let i = 0; i < this.trailPointsCount; i++) {
      this.trailPoints.push({ x: this.position.x, y: this.position.y });
    }
    
    // Add event listeners
    this.addEventListeners();
    
    // Start rendering
    this.render();
  }

  addEventListeners() {
    // Mouse movement
    document.addEventListener('mousemove', this.onMouseMove.bind(this));
    
    // Mouse state
    document.addEventListener('mousedown', this.onMouseDown.bind(this));
    document.addEventListener('mouseup', this.onMouseUp.bind(this));
    document.addEventListener('mouseenter', this.onMouseEnter.bind(this));
    document.addEventListener('mouseleave', this.onMouseLeave.bind(this));
    
    // Interactive elements
    this.addInteractiveListeners();
    
    // Touch events for mobile
    document.addEventListener('touchstart', this.hideCursor.bind(this));
    document.addEventListener('touchend', this.hideCursor.bind(this));
    
    // Window events
    window.addEventListener('resize', this.onResize.bind(this));
  }

  addInteractiveListeners() {
    // Add hover effect to interactive elements
    const interactiveElements = document.querySelectorAll('a, button, .btn, input, textarea, select, [data-cursor="interactive"]');
    
    interactiveElements.forEach(element => {
      element.addEventListener('mouseenter', () => this.setHovering(true));
      element.addEventListener('mouseleave', () => this.setHovering(false));
    });
  }

  onMouseMove(event) {
    // Update cursor position
    this.targetPosition.x = event.clientX;
    this.targetPosition.y = event.clientY;
    
    // Show cursor if it was hidden
    if (!this.isVisible) {
      this.showCursor();
    }
  }

  onMouseDown() {
    this.setActive(true);
  }

  onMouseUp() {
    this.setActive(false);
  }

  onMouseEnter() {
    this.showCursor();
  }

  onMouseLeave() {
    this.hideCursor();
  }

  onResize() {
    // Reset cursor position on resize to prevent it from being stuck
    this.position.x = window.innerWidth / 2;
    this.position.y = window.innerHeight / 2;
  }

  setActive(active) {
    // Handle cursor active state (e.g. when clicking)
    this.isActive = active;
    
    if (active) {
      this.cursor.classList.add('cursor-active');
    } else {
      this.cursor.classList.remove('cursor-active');
    }
  }

  setHovering(hovering) {
    // Handle cursor hover state (e.g. when over interactive elements)
    this.isHovering = hovering;
    
    if (hovering) {
      this.cursor.classList.add('cursor-link');
    } else {
      this.cursor.classList.remove('cursor-link');
    }
  }

  showCursor() {
    this.isVisible = true;
    this.cursor.style.opacity = 1;
  }

  hideCursor() {
    this.isVisible = false;
    this.cursor.style.opacity = 0;
  }

  updateCursorPosition() {
    // Smooth cursor movement with lerp
    this.position.x = utils.lerp(this.position.x, this.targetPosition.x, 0.15);
    this.position.y = utils.lerp(this.position.y, this.targetPosition.y, 0.15);
    
    // Calculate cursor speed for dynamic effects
    const deltaX = this.position.x - this.previousPosition.x;
    const deltaY = this.position.y - this.previousPosition.y;
    
    // Calculate cursor speed (distance traveled since last frame)
    const speed = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    // Update dot position with speed-based scaling
    this.cursorDot.style.transform = `translate(${this.position.x}px, ${this.position.y}px) scale(${1 + speed * 0.05})`;
    
    // Update outline with a slight delay for trailing effect
    this.cursorOutline.style.transform = `translate(${utils.lerp(this.previousPosition.x, this.position.x, 0.85)}px, ${utils.lerp(this.previousPosition.y, this.position.y, 0.85)}px) scale(${1 + speed * 0.05})`;
    
    // Update trail with dynamic opacity based on speed
    this.cursorTrail.style.transform = `translate(${this.position.x}px, ${this.position.y}px)`;
    this.cursorTrail.style.opacity = utils.clamp(speed * 0.02, 0, 0.5);
    
    // Update previous position for next frame
    this.previousPosition.x = this.position.x;
    this.previousPosition.y = this.position.y;
    
    // Update trail points (trail behind cursor)
    this.updateTrail();
  }

  updateTrail() {
    // Shift all points in the trail
    for (let i = this.trailPoints.length - 1; i > 0; i--) {
      this.trailPoints[i].x = this.trailPoints[i - 1].x;
      this.trailPoints[i].y = this.trailPoints[i - 1].y;
    }
    
    // Add current position to the beginning of the trail
    this.trailPoints[0].x = this.position.x;
    this.trailPoints[0].y = this.position.y;
  }

  render() {
    // Update cursor position
    this.updateCursorPosition();
    
    // Continue animation loop
    requestAnimationFrame(this.render.bind(this));
  }
}

// Initialize custom cursor
window.addEventListener('load', () => {
  window.cursor = new Cursor();
}); 