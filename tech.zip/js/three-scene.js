/**
 * Three.js Scene for Hero Section
 * Creates an interactive 3D background
 */

class HeroScene {
  constructor() {
    this.container = document.getElementById('hero-canvas');
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.mousePosition = { x: 0, y: 0 };
    this.targetMousePosition = { x: 0, y: 0 };
    this.clock = new THREE.Clock();
    this.initialized = false;
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.particles = [];
    this.particlesGroup = null;

    // Initialize scene if WebGL is supported
    if (utils.isWebGLSupported()) {
      this.init();
      this.createScene();
      this.createCamera();
      this.createRenderer();
      this.createLights();
      this.createGeometries();
      this.createMaterials();
      this.createObjects();
      this.createParticles();
      this.addEventListeners();
      this.resize();
      this.animate();
      this.initialized = true;
    } else {
      this.fallbackBackground();
    }
  }

  init() {
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x050517, 0.08);
  }

  createScene() {
    // Add background color
    this.scene.background = new THREE.Color(0x050517);
  }

  createCamera() {
    // Create perspective camera
    this.camera = new THREE.PerspectiveCamera(75, this.width / this.height, 0.1, 1000);
    this.camera.position.set(0, 0, 5);
    this.camera.lookAt(0, 0, 0);
    this.scene.add(this.camera);
  }

  createRenderer() {
    // Create WebGL renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.container,
      antialias: true,
      alpha: true
    });
    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    
    // Enable physically correct lighting
    this.renderer.physicallyCorrectLights = true;
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
  }

  createLights() {
    // Ambient light
    this.ambientLight = new THREE.AmbientLight(0x050517, 0.5);
    this.scene.add(this.ambientLight);

    // Point lights with different colors
    this.pointLight1 = new THREE.PointLight(0x00ffcc, 1, 20);
    this.pointLight1.position.set(5, 5, 5);
    this.scene.add(this.pointLight1);

    this.pointLight2 = new THREE.PointLight(0xff00aa, 1, 20);
    this.pointLight2.position.set(-5, -5, 5);
    this.scene.add(this.pointLight2);

    this.pointLight3 = new THREE.PointLight(0x7000ff, 1, 20);
    this.pointLight3.position.set(0, 0, 7);
    this.scene.add(this.pointLight3);
  }

  createGeometries() {
    // Create geometric primitives for our scene
    this.torusGeometry = new THREE.TorusGeometry(1, 0.3, 16, 100);
    this.sphereGeometry = new THREE.IcosahedronGeometry(1, 2);
    this.boxGeometry = new THREE.BoxGeometry(1, 1, 1);
    this.particleGeometry = new THREE.IcosahedronGeometry(0.1, 0);
  }

  createMaterials() {
    // Create materials for our objects
    this.primaryMaterial = new THREE.MeshStandardMaterial({
      color: 0x00ffcc,
      metalness: 0.8,
      roughness: 0.2,
      emissive: 0x00ffcc,
      emissiveIntensity: 0.2,
      wireframe: false,
      transparent: true,
      opacity: 0.9
    });

    this.secondaryMaterial = new THREE.MeshStandardMaterial({
      color: 0xff00aa,
      metalness: 0.8,
      roughness: 0.2,
      emissive: 0xff00aa,
      emissiveIntensity: 0.2,
      wireframe: false,
      transparent: true,
      opacity: 0.9
    });

    this.accentMaterial = new THREE.MeshStandardMaterial({
      color: 0x7000ff,
      metalness: 0.8,
      roughness: 0.2,
      emissive: 0x7000ff,
      emissiveIntensity: 0.2,
      wireframe: true,
      transparent: true,
      opacity: 0.9
    });

    this.particleMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.8
    });
  }

  createObjects() {
    // Create 3D objects
    this.torus = new THREE.Mesh(this.torusGeometry, this.primaryMaterial);
    this.torus.position.set(-2, 0, 0);
    this.torus.rotation.x = Math.PI / 4;
    this.scene.add(this.torus);

    this.sphere = new THREE.Mesh(this.sphereGeometry, this.secondaryMaterial);
    this.sphere.position.set(2, 0, 0);
    this.scene.add(this.sphere);

    this.box = new THREE.Mesh(this.boxGeometry, this.accentMaterial);
    this.box.position.set(0, -2, 0);
    this.box.rotation.y = Math.PI / 4;
    this.scene.add(this.box);

    // Create a group for all main objects
    this.objectsGroup = new THREE.Group();
    this.objectsGroup.add(this.torus);
    this.objectsGroup.add(this.sphere);
    this.objectsGroup.add(this.box);
    this.scene.add(this.objectsGroup);
  }

  createParticles() {
    // Create a group for particles
    this.particlesGroup = new THREE.Group();
    this.scene.add(this.particlesGroup);

    // Add multiple particles
    for (let i = 0; i < 100; i++) {
      this.addParticle();
    }
  }

  addParticle() {
    const particle = new THREE.Mesh(this.particleGeometry, this.particleMaterial.clone());
    
    // Random position within a sphere
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const radius = utils.random(2, 8);
    
    particle.position.x = radius * Math.sin(phi) * Math.cos(theta);
    particle.position.y = radius * Math.sin(phi) * Math.sin(theta);
    particle.position.z = radius * Math.cos(phi);
    
    // Random size
    const scale = utils.random(0.02, 0.1);
    particle.scale.set(scale, scale, scale);
    
    // Random color from our palette
    const colors = [0x00ffcc, 0xff00aa, 0x7000ff, 0xffffff];
    particle.material.color.setHex(colors[Math.floor(Math.random() * colors.length)]);
    
    // Add to scene
    this.particlesGroup.add(particle);
    
    // Save to array for animation
    this.particles.push({
      mesh: particle,
      initialPosition: particle.position.clone(),
      speed: utils.random(0.2, 1),
      amplitude: utils.random(0.1, 0.5),
      frequency: utils.random(0.5, 2)
    });
  }

  fallbackBackground() {
    // Create a gradient background for browsers without WebGL support
    this.container.style.background = 'radial-gradient(circle at center, #101036 0%, #050517 100%)';
  }

  updateMousePosition(event) {
    // Update mouse position normalized coordinates
    this.targetMousePosition.x = (event.clientX / this.width) * 2 - 1;
    this.targetMousePosition.y = -((event.clientY / this.height) * 2 - 1);
  }

  updateCamera() {
    // Smoothly move camera based on mouse position
    if (!utils.isMobile()) {
      this.mousePosition.x = utils.lerp(this.mousePosition.x, this.targetMousePosition.x, 0.03);
      this.mousePosition.y = utils.lerp(this.mousePosition.y, this.targetMousePosition.y, 0.03);
      
      this.camera.position.x = this.mousePosition.x * 2;
      this.camera.position.y = this.mousePosition.y * 2;
      this.camera.lookAt(0, 0, 0);
    }
  }

  updateObjects() {
    // Animate the main objects
    const time = this.clock.getElapsedTime();
    
    // Rotate the torus
    this.torus.rotation.x += 0.003;
    this.torus.rotation.y += 0.005;
    
    // Pulsate the sphere
    const pulseFactor = (Math.sin(time) + 1) * 0.1 + 0.9;
    this.sphere.scale.set(pulseFactor, pulseFactor, pulseFactor);
    
    // Rotate the box
    this.box.rotation.x += 0.004;
    this.box.rotation.y += 0.004;
    
    // Rotate the whole group slowly
    this.objectsGroup.rotation.y = Math.sin(time * 0.2) * 0.2;
    this.objectsGroup.rotation.x = Math.cos(time * 0.2) * 0.1;
  }

  updateParticles() {
    // Animate each particle
    const time = this.clock.getElapsedTime();
    
    this.particles.forEach(particle => {
      const { mesh, initialPosition, speed, amplitude, frequency } = particle;
      
      // Orbital movement
      mesh.position.x = initialPosition.x + Math.sin(time * speed * frequency) * amplitude;
      mesh.position.y = initialPosition.y + Math.cos(time * speed * frequency) * amplitude;
      mesh.position.z = initialPosition.z + Math.sin(time * speed * 0.5) * amplitude * 0.5;
      
      // Pulse the opacity
      mesh.material.opacity = (Math.sin(time * speed) + 1) * 0.25 + 0.5;
    });
    
    // Rotate the entire particle system
    this.particlesGroup.rotation.y = time * 0.05;
  }

  updateLights() {
    // Animate lights
    const time = this.clock.getElapsedTime();
    
    // Move point lights in circular patterns
    this.pointLight1.position.x = Math.sin(time * 0.3) * 5;
    this.pointLight1.position.y = Math.cos(time * 0.3) * 5;
    
    this.pointLight2.position.x = Math.sin(time * 0.4 + Math.PI) * 5;
    this.pointLight2.position.y = Math.cos(time * 0.4 + Math.PI) * 5;
    
    // Pulsate the center light
    this.pointLight3.intensity = (Math.sin(time) + 1) * 0.5 + 0.5;
  }

  resize() {
    // Handle window resize
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    
    // Update camera aspect ratio
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    
    // Update renderer size
    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  }

  addEventListeners() {
    // Add event listeners for interactivity
    window.addEventListener('resize', this.resize.bind(this));
    window.addEventListener('mousemove', this.updateMousePosition.bind(this));
    
    // Touch events for mobile
    window.addEventListener('touchmove', (event) => {
      if (event.touches.length > 0) {
        this.updateMousePosition({
          clientX: event.touches[0].clientX,
          clientY: event.touches[0].clientY
        });
      }
    });
  }

  animate() {
    if (!this.initialized) return;
    
    // Animation loop
    requestAnimationFrame(this.animate.bind(this));
    
    // Update all elements
    this.updateCamera();
    this.updateObjects();
    this.updateParticles();
    this.updateLights();
    
    // Render scene
    this.renderer.render(this.scene, this.camera);
  }
}

// Initialize the scene when the window loads
window.addEventListener('load', () => {
  window.heroScene = new HeroScene();
}); 