/**
 * Main Application
 * Initializes and coordinates all components of the futuristic interface
 */

class App {
  constructor() {
    this.initialized = false;
    
    // Initialize app after page loads
    window.addEventListener('load', this.init.bind(this));
  }

  init() {
    // Initialize navigation
    this.initNavigation();
    
    // Initialize form validation
    this.initForms();
    
    // Initialize smooth scrolling for anchor links
    this.initSmoothScrollLinks();
    
    // Initialize section transitions
    this.initSectionTransitions();
    
    // Hide cursor on touch devices
    this.handleTouchDevices();
    
    // Mark as initialized
    this.initialized = true;
    
    // Remove loading class after initialization
    // (actual loader animation handled by GSAP in animations.js)
    setTimeout(() => {
      document.body.classList.remove('loading');
    }, 3500);
  }

  initNavigation() {
    // Get navigation elements
    const navLinks = document.querySelectorAll('.nav-link, .mobile-link');
    
    // Add active class to nav links based on current section
    window.addEventListener('scroll', utils.throttle(() => {
      const scrollPosition = window.scrollY + 200;
      
      document.querySelectorAll('section').forEach(section => {
        if (section.id) {
          const sectionTop = section.offsetTop;
          const sectionHeight = section.offsetHeight;
          
          if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            // Remove active class from all links
            navLinks.forEach(link => {
              link.classList.remove('active');
            });
            
            // Add active class to current section links
            document.querySelectorAll(`.nav-link[href="#${section.id}"], .mobile-link[href="#${section.id}"]`).forEach(link => {
              link.classList.add('active');
            });
          }
        }
      });
    }, 100));
    
    // Handle navigation click events
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        // Only handle links to sections
        if (link.getAttribute('href').startsWith('#')) {
          e.preventDefault();
          
          const targetId = link.getAttribute('href');
          
          // Only scroll if target element exists
          if (targetId !== '#' && document.querySelector(targetId)) {
            // Use Lenis for smooth scrolling if available
            if (window.animations && window.animations.lenis) {
              window.animations.lenis.scrollTo(targetId);
            } else {
              document.querySelector(targetId).scrollIntoView({ behavior: 'smooth' });
            }
            
            // Close mobile menu if open
            const hamburger = document.querySelector('.hamburger');
            const mobileMenu = document.querySelector('.mobile-menu');
            
            if (hamburger && mobileMenu && mobileMenu.classList.contains('open')) {
              hamburger.classList.remove('active');
              mobileMenu.classList.remove('open');
            }
          }
        }
      });
    });
  }

  initForms() {
    // Get all forms
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Validate form
        const isValid = this.validateForm(form);
        
        if (isValid) {
          // Display success message (in a real application, you would submit the form data to a server)
          const submitButton = form.querySelector('button[type="submit"]');
          const originalText = submitButton.innerText;
          
          // Show success state
          submitButton.innerText = 'Success!';
          submitButton.style.backgroundColor = 'var(--color-success)';
          submitButton.disabled = true;
          
          // Reset form after delay
          setTimeout(() => {
            form.reset();
            submitButton.innerText = originalText;
            submitButton.style.backgroundColor = '';
            submitButton.disabled = false;
          }, 3000);
        }
      });
    });
  }

  validateForm(form) {
    // Get all required inputs
    const requiredInputs = form.querySelectorAll('[required]');
    let isValid = true;
    
    // Check each required input
    requiredInputs.forEach(input => {
      // Reset error state
      input.classList.remove('error');
      
      // Check if input is empty
      if (!input.value.trim()) {
        input.classList.add('error');
        isValid = false;
      }
      
      // Additional validation for email inputs
      if (input.type === 'email' && input.value.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(input.value.trim())) {
          input.classList.add('error');
          isValid = false;
        }
      }
    });
    
    return isValid;
  }

  initSmoothScrollLinks() {
    // Get all links with hash targets (not already handled by navigation)
    const scrollLinks = document.querySelectorAll('a[href^="#"]:not(.nav-link):not(.mobile-link)');
    
    scrollLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        const targetId = link.getAttribute('href');
        
        // Only handle links to actual elements
        if (targetId !== '#' && document.querySelector(targetId)) {
          e.preventDefault();
          
          // Use Lenis for smooth scrolling if available
          if (window.animations && window.animations.lenis) {
            window.animations.lenis.scrollTo(targetId);
          } else {
            document.querySelector(targetId).scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  }

  initSectionTransitions() {
    // Add intersection observer for section entry animations
    const sections = document.querySelectorAll('section');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
        } else {
          // Only remove the class if it's far out of view (to avoid removing during scrolling)
          if (entry.intersectionRatio < 0.1) {
            entry.target.classList.remove('in-view');
          }
        }
      });
    }, {
      threshold: [0.1, 0.5]
    });
    
    sections.forEach(section => {
      observer.observe(section);
    });
  }

  handleTouchDevices() {
    // Check if device is touch-enabled
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      document.body.classList.add('touch-device');
      
      // Hide custom cursor on touch devices
      const customCursor = document.querySelector('.custom-cursor');
      if (customCursor) {
        customCursor.style.display = 'none';
      }
    }
  }
}

// Initialize the application
window.app = new App(); 