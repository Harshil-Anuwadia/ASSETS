# NEXUS - Futuristic 3D Landing Page

A cutting-edge, futuristic landing page featuring advanced 3D interfaces and microinteractions.

## Features

- **Interactive 3D Hero Section**: Built with Three.js, featuring animated objects that respond to mouse movement
- **Custom SVG Graphics**: Futuristic illustrations and icons with animations
- **Advanced Logo Design**: SVG-based logo with loading and hover animations
- **Smooth Scrolling**: Integrated with Lenis for momentum-based smooth scrolling
- **Microinteractions**: Subtle animations on buttons, cards, and UI elements using GSAP and Anime.js
- **Floating Navigation**: Modern nav menu with morphing background and scroll-based effects
- **Responsive Design**: Fully responsive layout across all devices
- **Dark Mode Aesthetic**: Cyberpunk-inspired color palette with gradients, glows, and glassmorphism
- **Custom Cursor**: Interactive cursor with trailing particles and context-aware states

## Technologies Used

- HTML5 & CSS3
- JavaScript (ES6+)
- Three.js for 3D rendering
- GSAP with ScrollTrigger for advanced animations
- Lenis for smooth scrolling
- Anime.js for microinteractions
- CSS Variables for theming
- SVG for custom graphics and icons

## Getting Started

1. Clone this repository
2. Open `index.html` in your browser

No build tools or installation required - this is a pure HTML/CSS/JavaScript project.

## Browser Support

This project uses modern web technologies and is optimized for:

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is available for personal and commercial use.

## Credits

Created by [Your Name] 