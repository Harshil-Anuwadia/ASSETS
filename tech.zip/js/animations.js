/**
 * Animations using GSAP and Scroll Trigger
 * Controls all animated elements outside of the Three.js scene
 */

class Animations {
  constructor() {
    this.initialized = false;
    this.init();
  }

  init() {
    // Initialize only after page has loaded
    window.addEventListener('load', () => {
      // Register GSAP ScrollTrigger plugin
      gsap.registerPlugin(ScrollTrigger);
      
      // Initialize smooth scrolling with Lenis
      this.initSmoothScroll();
      
      // Initialize animations
      this.initLoader();
      this.initNavAnimation();
      this.initHeroAnimation();
      this.initFeaturesAnimation();
      this.initContactAnimation();
      this.initMicroInteractions();
      
      this.initialized = true;
    });
  }

  initSmoothScroll() {
    // Initialize Lenis for smooth scrolling
    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      direction: 'vertical',
      gestureDirection: 'vertical',
      smooth: true,
      smoothTouch: false,
      touchMultiplier: 2
    });

    // Connect Lenis to GSAP's ticker for better performance
    this.lenis.on('scroll', () => {
      ScrollTrigger.update();
    });

    gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);
  }

  initLoader() {
    // Animate the loader and reveal the page
    const tl = gsap.timeline({
      defaults: { 
        ease: 'power3.out'
      },
      onComplete: () => {
        document.body.classList.remove('loading');
      }
    });

    tl.to('.loader-progress', { 
      width: '100%', 
      duration: 3, 
      ease: 'power2.inOut' 
    })
    .to('.loader', { 
      opacity: 0, 
      duration: 0.5,
      pointerEvents: 'none'
    })
    .set('.loader', { 
      visibility: 'hidden'
    });
  }

  initNavAnimation() {
    // Animate navigation on scroll
    gsap.fromTo('.main-nav', 
      { 
        y: -100, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 1, 
        delay: 3.5 // After loader finishes
      }
    );
    
    // Change navigation appearance on scroll
    ScrollTrigger.create({
      start: 'top -100',
      end: 99999,
      toggleClass: { 
        className: 'scrolled', 
        targets: '.main-nav' 
      }
    });
    
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (hamburger && mobileMenu) {
      hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        mobileMenu.classList.toggle('open');
        
        if (mobileMenu.classList.contains('open')) {
          // Disable scrolling when menu is open
          this.lenis.stop();
          
          // Animate menu items
          gsap.fromTo('.mobile-link', 
            { 
              y: 20, 
              opacity: 0 
            },
            { 
              y: 0, 
              opacity: 1, 
              duration: 0.4,
              stagger: 0.1,
              ease: 'power2.out'
            }
          );
        } else {
          // Re-enable scrolling when menu closes
          this.lenis.start();
        }
      });
      
      // Close mobile menu when clicking on links
      document.querySelectorAll('.mobile-link').forEach(link => {
        link.addEventListener('click', () => {
          hamburger.classList.remove('active');
          mobileMenu.classList.remove('open');
          this.lenis.start();
        });
      });
    }
  }

  initHeroAnimation() {
    // Animate hero section elements
    const tl = gsap.timeline({ defaults: { ease: 'power3.out', delay: 3.5 } });
    
    tl.fromTo('.hero-title', 
      { 
        y: 100, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 1 
      }
    )
    .fromTo('.hero-subtitle', 
      { 
        y: 50, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8 
      }, 
      '-=0.6'
    )
    .fromTo('.hero-actions', 
      { 
        y: 50, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8 
      }, 
      '-=0.6'
    )
    .fromTo('.hero-scroll-indicator', 
      { 
        y: 20, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 0.7, 
        duration: 0.6 
      }, 
      '-=0.4'
    );
    
    // Parallax scroll effect on hero content
    gsap.to('.hero-content', {
      yPercent: -20,
      ease: 'none',
      scrollTrigger: {
        trigger: '.hero-section',
        start: 'top top',
        end: 'bottom top',
        scrub: true
      }
    });
  }

  initFeaturesAnimation() {
    // Animate section title
    gsap.fromTo('.features-section .section-title', 
      { 
        y: 50, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.features-section',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    );
    
    // Animate section subtitle
    gsap.fromTo('.features-section .section-subtitle', 
      { 
        y: 30, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.features-section',
          start: 'top 70%',
          end: 'top 40%',
          scrub: true
        }
      }
    );
    
    // Animate feature cards
    gsap.utils.toArray('.feature-card').forEach((card, i) => {
      gsap.fromTo(card, 
        { 
          y: 100, 
          opacity: 0 
        },
        { 
          y: 0, 
          opacity: 1, 
          duration: 1,
          scrollTrigger: {
            trigger: card,
            start: 'top 90%',
            end: 'top 60%',
            scrub: true
          }
        }
      );
    });
  }

  initContactAnimation() {
    // Animate contact section
    gsap.fromTo('.contact-section .section-title', 
      { 
        y: 50, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.contact-section',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    );
    
    gsap.fromTo('.contact-section .section-subtitle', 
      { 
        y: 30, 
        opacity: 0 
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.contact-section',
          start: 'top 70%',
          end: 'top 40%',
          scrub: true
        }
      }
    );
    
    // Animate contact form and info
    gsap.fromTo('.contact-form', 
      { 
        x: -50, 
        opacity: 0 
      },
      { 
        x: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.contact-container',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    );
    
    gsap.fromTo('.contact-info', 
      { 
        x: 50, 
        opacity: 0 
      },
      { 
        x: 0, 
        opacity: 1, 
        duration: 0.8,
        scrollTrigger: {
          trigger: '.contact-container',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    );
  }

  initMicroInteractions() {
    // Button hover animations
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
      button.addEventListener('mouseenter', () => {
        gsap.to(button, { 
          scale: 1.05, 
          duration: 0.3, 
          ease: 'power2.out' 
        });
      });
      
      button.addEventListener('mouseleave', () => {
        gsap.to(button, { 
          scale: 1, 
          duration: 0.3, 
          ease: 'power2.out' 
        });
      });
      
      button.addEventListener('mousedown', () => {
        gsap.to(button, { 
          scale: 0.95, 
          duration: 0.1, 
          ease: 'power2.out' 
        });
      });
      
      button.addEventListener('mouseup', () => {
        gsap.to(button, { 
          scale: 1.05, 
          duration: 0.1, 
          ease: 'power2.out' 
        });
      });
    });
    
    // Feature card hover animations
    const featureCards = document.querySelectorAll('.feature-card');
    
    featureCards.forEach(card => {
      const icon = card.querySelector('.feature-icon svg');
      
      card.addEventListener('mouseenter', () => {
        gsap.to(icon, {
          rotation: 10,
          scale: 1.1,
          duration: 0.4,
          ease: 'power2.out'
        });
      });
      
      card.addEventListener('mouseleave', () => {
        gsap.to(icon, {
          rotation: 0,
          scale: 1,
          duration: 0.4,
          ease: 'power2.out'
        });
      });
    });
    
    // Form input animations
    const formInputs = document.querySelectorAll('input, textarea, select');
    
    formInputs.forEach(input => {
      input.addEventListener('focus', () => {
        const label = input.previousElementSibling;
        if (label && label.tagName === 'LABEL') {
          gsap.to(label, {
            y: -5,
            color: '#00ffcc',
            duration: 0.3,
            ease: 'power2.out'
          });
        }
      });
      
      input.addEventListener('blur', () => {
        const label = input.previousElementSibling;
        if (label && label.tagName === 'LABEL') {
          if (input.value === '') {
            gsap.to(label, {
              y: 0,
              color: 'rgba(255, 255, 255, 0.87)',
              duration: 0.3,
              ease: 'power2.out'
            });
          } else {
            gsap.to(label, {
              color: 'rgba(255, 255, 255, 0.87)',
              duration: 0.3,
              ease: 'power2.out'
            });
          }
        }
      });
    });
    
    // Social icon hover animations
    const socialLinks = document.querySelectorAll('.social-link');
    
    socialLinks.forEach(link => {
      const icon = link.querySelector('svg');
      
      link.addEventListener('mouseenter', () => {
        gsap.to(icon, {
          rotation: 360,
          duration: 0.6,
          ease: 'power2.out'
        });
      });
      
      link.addEventListener('mouseleave', () => {
        gsap.to(icon, {
          rotation: 0,
          duration: 0.6,
          ease: 'power2.out'
        });
      });
    });
    
    // Nav link hover effect
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
      link.addEventListener('mouseenter', () => {
        const line = link.querySelector('::after');
        gsap.to(link, {
          textShadow: '0 0 10px rgba(0, 255, 204, 0.5)',
          duration: 0.3,
          ease: 'power2.out'
        });
      });
      
      link.addEventListener('mouseleave', () => {
        gsap.to(link, {
          textShadow: 'none',
          duration: 0.3,
          ease: 'power2.out'
        });
      });
    });
  }
}

// Initialize animations
window.animations = new Animations(); 