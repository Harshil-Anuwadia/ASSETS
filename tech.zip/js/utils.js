/**
 * Utility functions for the futuristic 3D interface
 */

// Smooth lerp function for animations
const lerp = (start, end, factor) => {
  return start + (end - start) * factor;
};

// Clamp value between min and max
const clamp = (value, min, max) => {
  return Math.min(Math.max(value, min), max);
};

// Map a value from one range to another
const map = (value, inMin, inMax, outMin, outMax) => {
  return ((value - inMin) * (outMax - outMin)) / (inMax - inMin) + outMin;
};

// Check if element is in viewport
const isInViewport = (element, offset = 0) => {
  const rect = element.getBoundingClientRect();
  return (
    rect.top <= (window.innerHeight - offset) &&
    rect.bottom >= offset &&
    rect.left <= (window.innerWidth - offset) &&
    rect.right >= offset
  );
};

// Check if mobile device
const isMobile = () => {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
};

// Preload images and return a promise
const preloadImages = (urls) => {
  return Promise.all(
    urls.map(url => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = url;
      });
    })
  );
};

// Get random number between min and max
const random = (min, max) => {
  return Math.random() * (max - min) + min;
};

// Throttle function calls
const throttle = (func, limit) => {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
};

// Debounce function calls
const debounce = (func, delay) => {
  let timeoutId;
  return function() {
    const args = arguments;
    const context = this;
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(context, args), delay);
  };
};

// Create a wave effect (for WebGL/Three.js)
const createWavePattern = (amplitude, frequency, time) => {
  return (x, z) => {
    return Math.sin(x * frequency + time) * amplitude +
           Math.sin(z * frequency + time) * amplitude;
  };
};

// Get normalized mouse position (-1 to 1)
const getNormalizedMousePos = (event) => {
  return {
    x: (event.clientX / window.innerWidth) * 2 - 1,
    y: -(event.clientY / window.innerHeight) * 2 + 1
  };
};

// Calculate distance between two points
const distance = (x1, y1, x2, y2) => {
  return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
};

// Check if WebGL is supported
const isWebGLSupported = () => {
  try {
    const canvas = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && 
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
  } catch (e) {
    return false;
  }
};

// Get transform values from element
const getTransformValues = (element) => {
  const transform = window.getComputedStyle(element).transform;
  if (transform === 'none') return { x: 0, y: 0, z: 0 };
  
  const matrix = transform.match(/^matrix3d\((.+)\)$/);
  if (matrix) {
    const values = matrix[1].split(', ');
    return {
      x: parseFloat(values[12]),
      y: parseFloat(values[13]),
      z: parseFloat(values[14])
    };
  }
  
  const matrix2d = transform.match(/^matrix\((.+)\)$/);
  if (matrix2d) {
    const values = matrix2d[1].split(', ');
    return {
      x: parseFloat(values[4]),
      y: parseFloat(values[5]),
      z: 0
    };
  }
  
  return { x: 0, y: 0, z: 0 };
};

// HSL to RGB conversion (for dynamic color manipulation)
const hslToRgb = (h, s, l) => {
  let r, g, b;

  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1/3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1/3);
  }

  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255)
  };
};

// Generate a neon glow CSS color
const getNeonGlow = (color, intensity = 1) => {
  return `0 0 ${5 * intensity}px ${color}, 0 0 ${10 * intensity}px ${color}, 0 0 ${15 * intensity}px ${color}`;
};

// Export utilities
window.utils = {
  lerp,
  clamp,
  map,
  isInViewport,
  isMobile,
  preloadImages,
  random,
  throttle,
  debounce,
  createWavePattern,
  getNormalizedMousePos,
  distance,
  isWebGLSupported,
  getTransformValues,
  hslToRgb,
  getNeonGlow
}; 